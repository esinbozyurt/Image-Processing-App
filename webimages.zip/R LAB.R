1+1
toplam = 3+3
toplam
toplam+1
sentence ='esin'
sentence


my_first_vector = c(1,2,3,4,5)
my_first_vector
sentence+1
my_first_vector[2]/2  
my_first_vector*2
my_first_vector[2:4]


sum(my_first_vector)
sd(my_first_vector)
mean(my_first_vector)


class(Lecture_1_data)
Lecture_1_data$YEAR
Lecture_1_data$Q1

Lecture_1_data[10:15,1:4]
Lecture_1_data[,1]

vector_1 = c(1:20)
vector_2 = c(11:30)
length((vector_1))
length(vector_2)

plot(x=vector_1,y=vector_2,type='1', xlim=c(0:30),ylim = c(1:30))
